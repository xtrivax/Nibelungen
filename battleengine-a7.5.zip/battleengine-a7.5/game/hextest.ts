tile 0:
    0 tiles/hex-earth-grass.png
tile 1:
    0 tiles/hex-earth.png
tile 2:
    0 tiles/hex-edge-n.png tiles/hex-edge-ne.png tiles/hex-edge-se.png tiles/hex-edge-s.png tiles/hex-edge-sw.png tiles/hex-edge-nw.png
tile 3:
    0 tiles/hex-edge-nw.png tiles/hex-edge-n.png tiles/hex-edge-ne.png tiles/hex-edge-se.png tiles/hex-edge-s.png tiles/hex-edge-sw.png
tile 4:
    0 tiles/hex-edge-sw.png tiles/hex-edge-nw.png tiles/hex-edge-n.png tiles/hex-edge-ne.png tiles/hex-edge-se.png tiles/hex-edge-s.png
tile 5:
    0 tiles/hex-edge-s.png tiles/hex-edge-sw.png tiles/hex-edge-nw.png tiles/hex-edge-n.png tiles/hex-edge-ne.png tiles/hex-edge-se.png