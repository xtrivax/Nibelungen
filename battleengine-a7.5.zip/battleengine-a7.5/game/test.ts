tile 0:
    0 tiles/light-earth-grass.png
    
tile 1:
    0 tiles/light-earth.png
    
tile 2:
    0 tiles/roots.png
    0 tiles/light-earth-grass.png
    
tile 3:
    0 tiles/light-earth-grass.png
    75 tiles/roots.png
    75 tiles/light-earth.png
    
tile 4:
    0 tiles/rock.png
    75 tiles/rock.png
    
tile 5:
    0 tiles/light-earth-grass-path-ns.png tiles/light-earth-grass-path-ew.png